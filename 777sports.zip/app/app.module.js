var app = angular.module("myApp", [
  "ngRoute",
  "ngCookies",
  "ngSanitize",
  "ngWebsocket",
  "googlechart",
  'ngMaterial', 
  'ngMessages',
  "ngResource"
]);
